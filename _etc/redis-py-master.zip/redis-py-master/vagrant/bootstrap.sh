#!/usr/bin/env bash

# need make to build redis
sudo apt-get install make
